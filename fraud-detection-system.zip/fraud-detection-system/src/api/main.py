"""
FastAPI serving endpoint for real-time fraud scoring.
Handles single transaction and batch prediction requests.
"""

from __future__ import annotations

import logging
import os
import time
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

from src.features.feature_engineering import FeatureEngineer
from src.features.feature_store import FeatureStore
from src.models.ensemble import FraudEnsemble

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

_ensemble: FraudEnsemble | None = None
_engineer: FeatureEngineer | None = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    global _ensemble, _engineer
    model_dir  = os.getenv("MODEL_DIR", "./models")
    redis_host = os.getenv("REDIS_HOST", "localhost")

    logger.info("Loading fraud detection model…")
    _ensemble = FraudEnsemble.load(model_dir)
    _engineer = FeatureEngineer(FeatureStore(host=redis_host))
    logger.info("Model ready.")
    yield


app = FastAPI(
    title="Fraud Detection API",
    description="Real-time fraud scoring with XGBoost + Isolation Forest ensemble",
    version="1.0.0",
    lifespan=lifespan,
)


class TransactionRequest(BaseModel):
    transaction_id: str
    user_id:        str
    amount:         float = Field(..., gt=0)
    merchant_id:    str   = ""
    mcc:            str   = "0000"
    timestamp:      float
    country:        str   = "US"
    currency:       str   = "USD"
    device_id:      str   = ""
    ip_address:     str   = ""
    channel:        str   = "online"

class PredictionResponse(BaseModel):
    transaction_id: str
    is_fraud:       bool
    fraud_score:    float
    latency_ms:     float

class BatchRequest(BaseModel):
    transactions: list[TransactionRequest] = Field(..., max_items=1000)

class BatchResponse(BaseModel):
    predictions:    list[PredictionResponse]
    total_latency_ms: float
    fraud_count:    int


@app.get("/health")
async def health():
    return {"status": "ok", "model_loaded": _ensemble is not None}


@app.post("/predict", response_model=PredictionResponse)
async def predict(req: TransactionRequest):
    if _ensemble is None:
        raise HTTPException(503, "Model not loaded")

    t0  = time.perf_counter()
    txn = req.model_dump()

    features             = _engineer.compute_features(txn)
    is_fraud, score      = _ensemble.predict_single(features)
    latency_ms           = (time.perf_counter() - t0) * 1000

    if is_fraud:
        logger.warning(f"FRAUD DETECTED: txn={req.transaction_id} score={score:.4f}")

    return PredictionResponse(
        transaction_id=req.transaction_id,
        is_fraud=is_fraud,
        fraud_score=round(score, 4),
        latency_ms=round(latency_ms, 2),
    )


@app.post("/predict/batch", response_model=BatchResponse)
async def predict_batch(req: BatchRequest):
    if _ensemble is None:
        raise HTTPException(503, "Model not loaded")

    t0          = time.perf_counter()
    predictions = []

    for txn_req in req.transactions:
        txn                  = txn_req.model_dump()
        features             = _engineer.compute_features(txn)
        is_fraud, score      = _ensemble.predict_single(features)
        predictions.append(PredictionResponse(
            transaction_id=txn_req.transaction_id,
            is_fraud=is_fraud,
            fraud_score=round(score, 4),
            latency_ms=0.0,
        ))

    total_ms = (time.perf_counter() - t0) * 1000
    return BatchResponse(
        predictions=predictions,
        total_latency_ms=round(total_ms, 2),
        fraud_count=sum(p.is_fraud for p in predictions),
    )
