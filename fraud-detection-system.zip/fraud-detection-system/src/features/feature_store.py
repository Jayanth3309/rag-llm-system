"""
Redis-backed feature store for real-time fraud detection.

Stores and retrieves:
  - User velocity windows  (txn counts + amount aggregates per time window)
  - User behavioral profile (historical patterns, known devices, countries)
  - Merchant statistics     (fraud rates, chargeback rates)
  - Device transaction counts
"""

from __future__ import annotations

import json
import logging
from typing import Any

import redis

logger = logging.getLogger(__name__)

# TTL constants
USER_WINDOW_TTL   = 7 * 24 * 3600   # 1 week
USER_PROFILE_TTL  = 30 * 24 * 3600  # 30 days
MERCHANT_TTL      = 24 * 3600       # 1 day
DEVICE_TTL        = 7 * 24 * 3600   # 1 week


class FeatureStore:
    """Thin wrapper around Redis for real-time feature reads and writes."""

    def __init__(self, host: str = "localhost", port: int = 6379, db: int = 0) -> None:
        self._client = redis.Redis(host=host, port=port, db=db, decode_responses=True)
        logger.info(f"FeatureStore connected to Redis at {host}:{port}")

    # ── User velocity windows ─────────────────────────────────────

    def get_user_window(self, user_id: str, window_hours: int) -> dict[str, Any]:
        key = f"user:velocity:{user_id}:{window_hours}h"
        raw = self._client.get(key)
        return json.loads(raw) if raw else {}

    def set_user_window(self, user_id: str, window_hours: int, data: dict) -> None:
        key = f"user:velocity:{user_id}:{window_hours}h"
        self._client.setex(key, USER_WINDOW_TTL, json.dumps(data))

    # ── User behavioral profile ───────────────────────────────────

    def get_user_profile(self, user_id: str) -> dict[str, Any]:
        key = f"user:profile:{user_id}"
        raw = self._client.get(key)
        return json.loads(raw) if raw else {}

    def set_user_profile(self, user_id: str, profile: dict) -> None:
        key = f"user:profile:{user_id}"
        self._client.setex(key, USER_PROFILE_TTL, json.dumps(profile))

    def update_user_profile(self, user_id: str, updates: dict) -> None:
        """Merge updates into an existing profile (or create new)."""
        profile = self.get_user_profile(user_id)
        profile.update(updates)
        self.set_user_profile(user_id, profile)

    # ── Merchant stats ────────────────────────────────────────────

    def get_merchant_stats(self, merchant_id: str) -> dict[str, Any]:
        key = f"merchant:stats:{merchant_id}"
        raw = self._client.get(key)
        return json.loads(raw) if raw else {}

    def set_merchant_stats(self, merchant_id: str, stats: dict) -> None:
        key = f"merchant:stats:{merchant_id}"
        self._client.setex(key, MERCHANT_TTL, json.dumps(stats))

    # ── Device counts ─────────────────────────────────────────────

    def get_device_txn_count(self, device_id: str) -> int:
        key = f"device:txn_count:{device_id}"
        val = self._client.get(key)
        return int(val) if val else 0

    def increment_device_txn_count(self, device_id: str) -> None:
        key = f"device:txn_count:{device_id}"
        self._client.incr(key)
        self._client.expire(key, DEVICE_TTL)

    # ── Health check ──────────────────────────────────────────────

    def ping(self) -> bool:
        try:
            return self._client.ping()
        except redis.ConnectionError:
            return False
