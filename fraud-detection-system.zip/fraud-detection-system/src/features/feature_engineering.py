"""
Feature engineering for real-time fraud detection.

Generates 80+ behavioral, velocity, and contextual features from
raw transaction events, combining live Redis lookups with
Spark Streaming window aggregations.

Feature groups:
  - Transaction-level  (amount, merchant, time)
  - Velocity features  (txn count / amount in N-hour windows)
  - Behavioral         (deviation from user's historical patterns)
  - Merchant-level     (merchant risk signals)
  - Device / channel   (IP, device, payment method signals)
"""

from __future__ import annotations

import math
from datetime import datetime
from typing import Any

import numpy as np

from src.features.feature_store import FeatureStore

# Velocity windows (in hours)
VELOCITY_WINDOWS = [1, 6, 24, 168]   # 1h, 6h, 1d, 1w

# High-risk merchant categories (MCC codes)
HIGH_RISK_MCC = {5912, 7995, 6010, 6011, 5933, 9400}


class FeatureEngineer:
    """
    Assembles a feature vector for a single transaction event.
    Reads historical aggregates from the Redis feature store.
    """

    def __init__(self, feature_store: FeatureStore) -> None:
        self.fs = feature_store

    def compute_features(self, txn: dict[str, Any]) -> dict[str, float]:
        """
        Compute all features for a transaction dict.

        Expected keys in `txn`:
            user_id, amount, merchant_id, mcc, timestamp,
            country, currency, device_id, ip_address, channel
        """
        features: dict[str, float] = {}

        features.update(self._transaction_features(txn))
        features.update(self._velocity_features(txn))
        features.update(self._behavioral_features(txn))
        features.update(self._merchant_features(txn))
        features.update(self._device_features(txn))

        return features

    # ── Transaction-level features ───────────────────────────────

    def _transaction_features(self, txn: dict) -> dict[str, float]:
        ts = datetime.fromtimestamp(txn["timestamp"])
        return {
            "amount":                  float(txn["amount"]),
            "amount_log":              math.log1p(float(txn["amount"])),
            "hour_of_day":             float(ts.hour),
            "day_of_week":             float(ts.weekday()),
            "is_weekend":              float(ts.weekday() >= 5),
            "is_night":                float(ts.hour < 6 or ts.hour >= 22),
            "is_foreign_currency":     float(txn.get("currency", "USD") != "USD"),
            "is_high_risk_mcc":        float(int(txn.get("mcc", 0)) in HIGH_RISK_MCC),
            "is_card_present":         float(txn.get("channel", "") == "pos"),
            "is_online":               float(txn.get("channel", "") == "online"),
        }

    # ── Velocity features ────────────────────────────────────────

    def _velocity_features(self, txn: dict) -> dict[str, float]:
        uid   = txn["user_id"]
        amt   = float(txn["amount"])
        feats = {}

        for window_h in VELOCITY_WINDOWS:
            hist = self.fs.get_user_window(uid, window_hours=window_h)
            txn_count = float(hist.get("txn_count", 0))
            txn_sum   = float(hist.get("amount_sum", 0.0))
            txn_max   = float(hist.get("amount_max", 0.0))

            feats[f"txn_count_{window_h}h"]       = txn_count
            feats[f"amount_sum_{window_h}h"]       = txn_sum
            feats[f"amount_max_{window_h}h"]       = txn_max
            feats[f"amount_mean_{window_h}h"]      = txn_sum / max(txn_count, 1)
            feats[f"txn_per_hour_{window_h}h"]     = txn_count / max(window_h, 1)
            feats[f"amount_ratio_{window_h}h"]     = amt / max(txn_sum, 1.0)

        return feats

    # ── Behavioral deviation features ────────────────────────────

    def _behavioral_features(self, txn: dict) -> dict[str, float]:
        uid     = txn["user_id"]
        amt     = float(txn["amount"])
        profile = self.fs.get_user_profile(uid)

        mean_amt = float(profile.get("mean_amount", amt))
        std_amt  = float(profile.get("std_amount",  1.0)) or 1.0

        z_score        = (amt - mean_amt) / std_amt
        usual_hours    = set(profile.get("usual_hours", []))
        usual_mccs     = set(profile.get("usual_mccs",  []))
        ts             = datetime.fromtimestamp(txn["timestamp"])

        return {
            "amount_zscore":              z_score,
            "amount_vs_mean_ratio":       amt / max(mean_amt, 1.0),
            "is_unusual_hour":            float(ts.hour not in usual_hours),
            "is_new_merchant":            float(txn.get("merchant_id") not in
                                               set(profile.get("known_merchants", []))),
            "is_new_country":             float(txn.get("country") not in
                                               set(profile.get("known_countries", []))),
            "is_unusual_mcc":             float(int(txn.get("mcc", 0)) not in usual_mccs),
            "days_since_last_txn":        float(profile.get("days_since_last_txn", 0)),
            "unique_merchants_30d":       float(profile.get("unique_merchants_30d", 0)),
            "unique_countries_30d":       float(profile.get("unique_countries_30d", 0)),
        }

    # ── Merchant-level features ──────────────────────────────────

    def _merchant_features(self, txn: dict) -> dict[str, float]:
        mid   = txn.get("merchant_id", "unknown")
        minfo = self.fs.get_merchant_stats(mid)

        return {
            "merchant_fraud_rate_30d":    float(minfo.get("fraud_rate_30d",   0.0)),
            "merchant_chargeback_rate":   float(minfo.get("chargeback_rate",  0.0)),
            "merchant_avg_txn_amount":    float(minfo.get("avg_txn_amount",   0.0)),
            "merchant_txn_volume_30d":    float(minfo.get("txn_volume_30d",   0.0)),
            "merchant_new_user_ratio":    float(minfo.get("new_user_ratio",   0.0)),
        }

    # ── Device / channel features ────────────────────────────────

    def _device_features(self, txn: dict) -> dict[str, float]:
        uid       = txn["user_id"]
        device_id = txn.get("device_id", "")
        ip        = txn.get("ip_address", "")
        profile   = self.fs.get_user_profile(uid)

        return {
            "is_new_device":     float(device_id not in set(profile.get("known_devices", []))),
            "is_new_ip":         float(ip not in set(profile.get("known_ips", []))),
            "device_txn_count":  float(self.fs.get_device_txn_count(device_id)),
        }


FEATURE_NAMES: list[str] = [
    "amount", "amount_log", "hour_of_day", "day_of_week",
    "is_weekend", "is_night", "is_foreign_currency", "is_high_risk_mcc",
    "is_card_present", "is_online",
    *[f"txn_count_{w}h"   for w in VELOCITY_WINDOWS],
    *[f"amount_sum_{w}h"  for w in VELOCITY_WINDOWS],
    *[f"amount_max_{w}h"  for w in VELOCITY_WINDOWS],
    *[f"amount_mean_{w}h" for w in VELOCITY_WINDOWS],
    *[f"txn_per_hour_{w}h" for w in VELOCITY_WINDOWS],
    *[f"amount_ratio_{w}h" for w in VELOCITY_WINDOWS],
    "amount_zscore", "amount_vs_mean_ratio",
    "is_unusual_hour", "is_new_merchant", "is_new_country",
    "is_unusual_mcc", "days_since_last_txn",
    "unique_merchants_30d", "unique_countries_30d",
    "merchant_fraud_rate_30d", "merchant_chargeback_rate",
    "merchant_avg_txn_amount", "merchant_txn_volume_30d",
    "merchant_new_user_ratio",
    "is_new_device", "is_new_ip", "device_txn_count",
]
