"""
Fraud detection ensemble: XGBoost (supervised) + Isolation Forest (unsupervised).

Combines calibrated probabilities from both models with a weighted average.
XGBoost captures known fraud patterns; Isolation Forest catches novel anomalies.
"""

from __future__ import annotations

import logging
import pickle
from pathlib import Path

import numpy as np
from sklearn.ensemble import IsolationForest
from sklearn.calibration import CalibratedClassifierCV
from sklearn.preprocessing import StandardScaler
from xgboost import XGBClassifier

logger = logging.getLogger(__name__)

# Ensemble weights (tuned on validation set)
XGB_WEIGHT = 0.70
ISO_WEIGHT = 0.30

FRAUD_THRESHOLD = 0.50   # flag as fraud above this combined score


class FraudEnsemble:
    """
    Two-model ensemble for fraud detection.

    Training:
        ensemble = FraudEnsemble()
        ensemble.fit(X_train, y_train)
        ensemble.save("./models")

    Inference:
        ensemble = FraudEnsemble.load("./models")
        score = ensemble.predict_proba(features)   # float in [0, 1]
        is_fraud = ensemble.predict(features)       # bool
    """

    def __init__(
        self,
        xgb_weight:      float = XGB_WEIGHT,
        iso_weight:      float = ISO_WEIGHT,
        fraud_threshold: float = FRAUD_THRESHOLD,
    ) -> None:
        self.xgb_weight      = xgb_weight
        self.iso_weight      = iso_weight
        self.fraud_threshold = fraud_threshold

        self._xgb     = self._build_xgb()
        self._iso     = IsolationForest(n_estimators=200, contamination=0.008, random_state=42, n_jobs=-1)
        self._scaler  = StandardScaler()
        self._fitted  = False

    # ── Model construction ───────────────────────────────────────

    @staticmethod
    def _build_xgb() -> XGBClassifier:
        return XGBClassifier(
            n_estimators=500,
            max_depth=6,
            learning_rate=0.05,
            subsample=0.8,
            colsample_bytree=0.8,
            scale_pos_weight=125,   # ~0.8% fraud rate → 1/0.008 ≈ 125
            eval_metric="aucpr",
            use_label_encoder=False,
            tree_method="hist",
            random_state=42,
            n_jobs=-1,
        )

    # ── Training ─────────────────────────────────────────────────

    def fit(
        self,
        X_train: np.ndarray,
        y_train: np.ndarray,
        X_val:   np.ndarray | None = None,
        y_val:   np.ndarray | None = None,
    ) -> "FraudEnsemble":
        logger.info(f"Training ensemble on {len(X_train):,} samples "
                    f"({int(y_train.sum()):,} fraud, {int((1-y_train).sum()):,} legit)")

        X_scaled = self._scaler.fit_transform(X_train)

        # XGBoost with early stopping
        eval_set = [(X_val, y_val)] if X_val is not None else None
        self._xgb.fit(
            X_scaled, y_train,
            eval_set=eval_set,
            verbose=100,
            early_stopping_rounds=30 if eval_set else None,
        )

        # Isolation Forest (unsupervised — train on legit transactions only)
        legit_mask = y_train == 0
        self._iso.fit(X_scaled[legit_mask])

        self._fitted = True
        logger.info("Ensemble training complete.")
        return self

    # ── Inference ────────────────────────────────────────────────

    def predict_proba(self, X: np.ndarray) -> np.ndarray:
        """Return fraud probability for each sample (float in [0, 1])."""
        self._check_fitted()
        X_scaled = self._scaler.transform(X)

        xgb_proba = self._xgb.predict_proba(X_scaled)[:, 1]

        # Isolation Forest: scores are negative; convert to [0,1] anomaly probability
        iso_scores  = self._iso.score_samples(X_scaled)
        iso_min, iso_max = iso_scores.min(), iso_scores.max()
        iso_proba   = 1.0 - (iso_scores - iso_min) / max(iso_max - iso_min, 1e-8)

        combined = self.xgb_weight * xgb_proba + self.iso_weight * iso_proba
        return np.clip(combined, 0.0, 1.0)

    def predict(self, X: np.ndarray) -> np.ndarray:
        """Return binary fraud labels (1 = fraud, 0 = legit)."""
        return (self.predict_proba(X) >= self.fraud_threshold).astype(int)

    def predict_single(self, features: dict) -> tuple[bool, float]:
        """
        Predict fraud for a single feature dict.
        Returns (is_fraud, fraud_score).
        """
        from src.features.feature_engineering import FEATURE_NAMES
        x = np.array([[features.get(f, 0.0) for f in FEATURE_NAMES]], dtype=np.float32)
        score    = float(self.predict_proba(x)[0])
        is_fraud = score >= self.fraud_threshold
        return is_fraud, score

    # ── Persistence ──────────────────────────────────────────────

    def save(self, directory: str | Path) -> None:
        path = Path(directory)
        path.mkdir(parents=True, exist_ok=True)
        with open(path / "ensemble.pkl", "wb") as f:
            pickle.dump({
                "xgb":       self._xgb,
                "iso":       self._iso,
                "scaler":    self._scaler,
                "xgb_weight":    self.xgb_weight,
                "iso_weight":    self.iso_weight,
                "fraud_threshold": self.fraud_threshold,
            }, f)
        logger.info(f"Ensemble saved to {path}")

    @classmethod
    def load(cls, directory: str | Path) -> "FraudEnsemble":
        path = Path(directory)
        with open(path / "ensemble.pkl", "rb") as f:
            data = pickle.load(f)
        instance = cls(
            xgb_weight=data["xgb_weight"],
            iso_weight=data["iso_weight"],
            fraud_threshold=data["fraud_threshold"],
        )
        instance._xgb    = data["xgb"]
        instance._iso    = data["iso"]
        instance._scaler = data["scaler"]
        instance._fitted = True
        logger.info(f"Ensemble loaded from {path}")
        return instance

    def _check_fitted(self) -> None:
        if not self._fitted:
            raise RuntimeError("Model not fitted. Call fit() or load() first.")
