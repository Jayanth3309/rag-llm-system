"""
Model monitoring: detects feature and prediction drift in production.

Uses:
  - PSI  (Population Stability Index)  for feature distribution shift
  - KS test                            for score distribution shift
  - Automated retraining trigger       when drift exceeds threshold
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field

import numpy as np
from scipy import stats

logger = logging.getLogger(__name__)

# Thresholds
PSI_WARNING  = 0.10   # slight shift
PSI_CRITICAL = 0.25   # significant shift — trigger retraining
KS_P_VALUE   = 0.05   # KS test significance level


@dataclass
class DriftReport:
    feature:      str
    psi:          float
    ks_statistic: float
    ks_p_value:   float
    drifted:      bool
    severity:     str   # "none", "warning", "critical"


@dataclass
class MonitoringResult:
    feature_reports:  list[DriftReport] = field(default_factory=list)
    score_drift:      bool  = False
    ks_p_value:       float = 1.0
    n_drifted:        int   = 0
    should_retrain:   bool  = False

    def summary(self) -> str:
        lines = [
            f"Features monitored: {len(self.feature_reports)}",
            f"Drifted features:   {self.n_drifted}",
            f"Score drift:        {self.score_drift} (p={self.ks_p_value:.4f})",
            f"Retrain triggered:  {self.should_retrain}",
        ]
        if self.n_drifted:
            top = sorted(self.feature_reports, key=lambda r: r.psi, reverse=True)[:5]
            lines.append("Top drifted features:")
            for r in top:
                lines.append(f"  {r.feature:<35} PSI={r.psi:.4f} [{r.severity}]")
        return "\n".join(lines)


class DriftDetector:
    """
    Monitors feature distributions and model score distributions
    between a reference window (training) and a current window (production).
    """

    def __init__(
        self,
        psi_warning:  float = PSI_WARNING,
        psi_critical: float = PSI_CRITICAL,
        ks_alpha:     float = KS_P_VALUE,
        n_bins:       int   = 10,
    ) -> None:
        self.psi_warning  = psi_warning
        self.psi_critical = psi_critical
        self.ks_alpha     = ks_alpha
        self.n_bins       = n_bins

    # ── Main entry point ─────────────────────────────────────────

    def detect(
        self,
        reference: np.ndarray,
        current:   np.ndarray,
        feature_names: list[str],
        ref_scores: np.ndarray | None = None,
        cur_scores: np.ndarray | None = None,
    ) -> MonitoringResult:
        """
        Detect drift between reference and current feature distributions.

        Args:
            reference:     Reference feature matrix (n_ref, n_features)
            current:       Current feature matrix   (n_cur, n_features)
            feature_names: Names for each feature column
            ref_scores:    Reference fraud score distribution (optional)
            cur_scores:    Current fraud score distribution  (optional)

        Returns:
            MonitoringResult with per-feature drift reports and retraining flag.
        """
        if reference.shape[1] != current.shape[1]:
            raise ValueError(
                f"Feature count mismatch: reference={reference.shape[1]}, current={current.shape[1]}"
            )

        reports = []
        for i, name in enumerate(feature_names):
            report = self._check_feature(name, reference[:, i], current[:, i])
            reports.append(report)

        n_drifted = sum(r.drifted for r in reports)
        n_critical = sum(r.severity == "critical" for r in reports)

        # Score distribution drift
        score_drift, ks_p = False, 1.0
        if ref_scores is not None and cur_scores is not None:
            ks_stat, ks_p = stats.ks_2samp(ref_scores, cur_scores)
            score_drift   = ks_p < self.ks_alpha

        should_retrain = n_critical > 0 or score_drift

        result = MonitoringResult(
            feature_reports=reports,
            score_drift=score_drift,
            ks_p_value=ks_p,
            n_drifted=n_drifted,
            should_retrain=should_retrain,
        )

        logger.info(f"Drift detection complete.\n{result.summary()}")
        if should_retrain:
            logger.warning("RETRAINING TRIGGERED — significant drift detected.")

        return result

    # ── Per-feature PSI ──────────────────────────────────────────

    def _check_feature(
        self,
        name:      str,
        ref_vals:  np.ndarray,
        cur_vals:  np.ndarray,
    ) -> DriftReport:
        psi          = self._compute_psi(ref_vals, cur_vals)
        ks_stat, ks_p = stats.ks_2samp(ref_vals, cur_vals)

        drifted  = psi > self.psi_warning or ks_p < self.ks_alpha
        if psi >= self.psi_critical:
            severity = "critical"
        elif psi >= self.psi_warning:
            severity = "warning"
        else:
            severity = "none"

        return DriftReport(
            feature=name,
            psi=round(psi, 6),
            ks_statistic=round(float(ks_stat), 6),
            ks_p_value=round(float(ks_p), 6),
            drifted=drifted,
            severity=severity,
        )

    def _compute_psi(self, ref: np.ndarray, cur: np.ndarray) -> float:
        """
        Population Stability Index between two univariate distributions.
        PSI < 0.10: no shift  |  0.10-0.25: moderate  |  > 0.25: significant
        """
        eps = 1e-8
        all_vals = np.concatenate([ref, cur])
        bins     = np.percentile(all_vals, np.linspace(0, 100, self.n_bins + 1))
        bins     = np.unique(bins)
        if len(bins) < 2:
            return 0.0

        ref_counts = np.histogram(ref, bins=bins)[0].astype(float) + eps
        cur_counts = np.histogram(cur, bins=bins)[0].astype(float) + eps

        ref_pct = ref_counts / ref_counts.sum()
        cur_pct = cur_counts / cur_counts.sum()

        psi = np.sum((cur_pct - ref_pct) * np.log(cur_pct / ref_pct))
        return float(psi)
