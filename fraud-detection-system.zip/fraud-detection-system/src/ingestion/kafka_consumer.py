"""
Spark Structured Streaming consumer.

Reads transactions from Kafka, computes features in micro-batches,
scores each transaction with the fraud ensemble, and writes
fraud alerts back to a Kafka output topic.

Run:
    python -m src.ingestion.kafka_consumer \
        --bootstrap-servers localhost:9092 \
        --model-dir ./models
"""

from __future__ import annotations

import argparse
import json
import logging
import os
from typing import Iterator

from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from pyspark.sql.types import (
    FloatType, StringType, StructField, StructType, BooleanType
)

from src.features.feature_engineering import FeatureEngineer, FEATURE_NAMES
from src.features.feature_store import FeatureStore
from src.models.ensemble import FraudEnsemble

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

INPUT_TOPIC  = "transactions"
OUTPUT_TOPIC = "fraud_alerts"

TRANSACTION_SCHEMA = StructType([
    StructField("transaction_id", StringType()),
    StructField("user_id",        StringType()),
    StructField("amount",         FloatType()),
    StructField("merchant_id",    StringType()),
    StructField("mcc",            StringType()),
    StructField("timestamp",      FloatType()),
    StructField("country",        StringType()),
    StructField("currency",       StringType()),
    StructField("device_id",      StringType()),
    StructField("ip_address",     StringType()),
    StructField("channel",        StringType()),
])

OUTPUT_SCHEMA = StructType([
    StructField("transaction_id", StringType()),
    StructField("user_id",        StringType()),
    StructField("fraud_score",    FloatType()),
    StructField("is_fraud",       BooleanType()),
    StructField("amount",         FloatType()),
    StructField("timestamp",      FloatType()),
])


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser()
    p.add_argument("--bootstrap-servers", default="localhost:9092")
    p.add_argument("--model-dir",         default="./models")
    p.add_argument("--redis-host",        default="localhost")
    p.add_argument("--batch-interval",    type=int, default=10)
    return p.parse_args()


def build_spark_session(app_name: str = "FraudDetection") -> SparkSession:
    return (
        SparkSession.builder
        .appName(app_name)
        .config("spark.jars.packages",
                "org.apache.spark:spark-sql-kafka-0-10_2.12:3.5.0")
        .config("spark.sql.streaming.checkpointLocation", "/tmp/fraud_checkpoints")
        .config("spark.executor.memory", "4g")
        .config("spark.sql.shuffle.partitions", "8")
        .getOrCreate()
    )


def score_batch(
    batch_df,
    batch_id: int,
    ensemble: FraudEnsemble,
    feature_engineer: FeatureEngineer,
) -> None:
    """Process a micro-batch: compute features, score, emit alerts."""
    if batch_df.isEmpty():
        return

    rows    = batch_df.collect()
    results = []

    for row in rows:
        txn = row.asDict()
        try:
            features  = feature_engineer.compute_features(txn)
            is_fraud, score = ensemble.predict_single(features)
            results.append({
                "transaction_id": txn["transaction_id"],
                "user_id":        txn["user_id"],
                "fraud_score":    round(score, 4),
                "is_fraud":       is_fraud,
                "amount":         txn["amount"],
                "timestamp":      txn["timestamp"],
            })
        except Exception as e:
            logger.error(f"Error scoring txn {txn.get('transaction_id')}: {e}")

    fraud_alerts = [r for r in results if r["is_fraud"]]
    if fraud_alerts:
        logger.warning(f"Batch {batch_id}: {len(fraud_alerts)} fraud alerts out of {len(results)} txns")

    # In production: write results to Kafka output topic and update feature store


def main() -> None:
    args    = parse_args()
    spark   = build_spark_session()

    ensemble         = FraudEnsemble.load(args.model_dir)
    feature_store    = FeatureStore(host=args.redis_host)
    feature_engineer = FeatureEngineer(feature_store)

    # Read from Kafka
    raw_stream = (
        spark.readStream
        .format("kafka")
        .option("kafka.bootstrap.servers", args.bootstrap_servers)
        .option("subscribe", INPUT_TOPIC)
        .option("startingOffsets", "latest")
        .option("maxOffsetsPerTrigger", 10_000)
        .load()
    )

    # Parse JSON payload
    parsed = (
        raw_stream
        .select(F.from_json(F.col("value").cast("string"), TRANSACTION_SCHEMA).alias("data"))
        .select("data.*")
        .filter(F.col("transaction_id").isNotNull())
    )

    # Start streaming query
    query = (
        parsed.writeStream
        .foreachBatch(lambda df, bid: score_batch(df, bid, ensemble, feature_engineer))
        .trigger(processingTime=f"{args.batch_interval} seconds")
        .option("checkpointLocation", "/tmp/fraud_checkpoints")
        .start()
    )

    logger.info(f"Streaming fraud detection started on topic '{INPUT_TOPIC}'")
    query.awaitTermination()


if __name__ == "__main__":
    main()
